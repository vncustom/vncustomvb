function execute() {
    return Response.success([
        {title: "玄幻魔法", input: "http://www.bqxs520.com/xuanhuan.html", script: "gen.js"},
        {title: "都市言情", input: "http://www.bqxs520.com/dushi.html", script: "gen.js"},
        {title: "武侠修真", input: "http://www.bqxs520.com/wuxia.html", script: "gen.js"},
        {title: "历史军事", input: "http://www.bqxs520.com/lishi.html", script: "gen.js"},
        {title: "恐怖科幻", input: "http://www.bqxs520.com/kehuan.html", script: "gen.js"},
        {title: "网游同人", input: "http://www.bqxs520.com/wangyou.html", script: "gen.js"},
        {title: "完本小说", input: "http://www.bqxs520.com/wanben.html", script: "gen.js"}
    ]);
}